package bigdata.spark_applications

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.hadoop.io.{Text, LongWritable}
import org.apache.hadoop.mapred.TextInputFormat

object Assignment1 {

 
  def check(row: String, value:String) = row.contains(value)
  
  def main(args:Array[String]) = {
  
    val sc = new SparkContext("local", "loading a CSV file")
    val sqlContext = new org.apache.spark.sql.SQLContext(sc)
    
    //val finding_string : String = "empower"
    val set_finding_string = List("empower", "lamenting", "whistles", "burn", "weathercock","shrivelled")
    
	var file_path = "/home/hduser/SCALA/jason.txt"
    println(file_path)
    val myfilerdd = sc.textFile(file_path)
    
    
    for (word <- set_finding_string)
      {
        println(word)
        myfilerdd.filter(check(_,word)).foreach(println)
      }
    
    System.in.read()
    sc.stop()

 }

  
}


